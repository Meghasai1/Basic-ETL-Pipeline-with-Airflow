CREATE TABLE top_level_domains(
    Domain VARCHAR(30), 
    Type VARCHAR(30), 
    SponsoringOrganization VARCHAR(30), 
    Date DATE
);
