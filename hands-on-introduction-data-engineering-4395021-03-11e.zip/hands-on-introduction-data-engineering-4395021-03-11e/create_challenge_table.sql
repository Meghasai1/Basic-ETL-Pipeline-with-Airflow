CREATE TABLE sp_500_sector_count(
    Sector VARCHAR(30), 
    Count INTEGER,
    Date DATE
);
